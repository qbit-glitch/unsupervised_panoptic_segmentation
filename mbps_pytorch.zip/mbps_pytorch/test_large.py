import torch
import torch.nn as nn

class TestModule(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(10, 20)
        self.fc2 = nn.Linear(20, 10)
    
    def forward(self, x):
        x = self.fc1(x)
        x = torch.relu(x)
        x = self.fc2(x)
        return x

# This is a long comment to test if there is a size limit on the WriteFile tool
# Line 1
# Line 2
# Line 3
# Line 4
# Line 5
# Line 6
# Line 7
# Line 8
# Line 9
# Line 10
# Line 11
# Line 12
# Line 13
# Line 14
# Line 15
# Line 16
# Line 17
# Line 18
# Line 19
# Line 20
# Line 21
# Line 22
# Line 23
# Line 24
# Line 25
# Line 26
# Line 27
# Line 28
# Line 29
# Line 30
# Line 31
# Line 32
# Line 33
# Line 34
# Line 35
# Line 36
# Line 37
# Line 38
# Line 39
# Line 40
# Line 41
# Line 42
# Line 43
# Line 44
# Line 45
# Line 46
# Line 47
# Line 48
# Line 49
# Line 50
