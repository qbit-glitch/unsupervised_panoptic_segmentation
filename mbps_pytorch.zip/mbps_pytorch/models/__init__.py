"""Model architecture modules."""
