"""Stuff-things classifier modules."""
